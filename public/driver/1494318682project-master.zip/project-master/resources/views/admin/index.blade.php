@extends('layouts.admin')

@section('content')

    <h1>Admin Dashboard</h1>



    @stop